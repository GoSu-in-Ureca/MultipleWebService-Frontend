import React from "react";

const WrongPathUser = () => {
    return (
        <>
            요청하신 사용자는 존재하지 않습니다.
        </>
    );
}

export default WrongPathUser;
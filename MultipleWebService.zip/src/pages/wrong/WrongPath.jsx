import React from "react";

const WrongPath = () => {
    return (
        <>
            잘못된 페이지 경로
        </>
    );
}

export default WrongPath;
### clone 후에 npm install
---
### 추가한 의존성
1. axios
2. react
3. react_dom
4. react-router-dom
5. recoil
8. styled-componenets
9. intersection-observer
10. firebase
11. react-copy-to-clipboard
---
### 실행 명령어
###### 내 pc에서만 접속 가능
1. npm run dev
###### 다른 pc에서 접속 허용
2. npm run dev -- --host